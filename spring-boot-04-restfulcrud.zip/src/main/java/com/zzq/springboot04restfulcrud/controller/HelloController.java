package com.zzq.springboot04restfulcrud.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * @author ZZQ
 * @date 2018/8/30 16:24
 */
@Controller
@RequestMapping("/user")
public class HelloController {


    @PostMapping("/login")
    public String login(String username, String password, HttpServletRequest request){
        if(username.equals("username") && "password".equals(password)){
            request.getSession().setAttribute("username",username);
            return  "redirect:/main.html" ;
        }else {
            request.setAttribute("msg","用户名密码错误");
            return  "login";
        }

    }




}
